// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3.

package ds.p4_webservice;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

import java.util.ArrayList;
import java.util.Arrays;

/*
 * The MongoDBManager handles all communication with the MongoDB Atlas database.
 * It is responsible for storing each mobile interaction as a log document,
 * retrieving logs for the dashboard, and computing analytics from the stored data.
 */
public class MongoDBManager {

    /*
     * Stores the MongoDB Atlas connection string used to connect to the database.
     */
    private static final String URI =
            "mongodb://rmurugan:rmurugan123@ac-llcnnor-shard-00-02.l3iji5w.mongodb.net:27017,ac-llcnnor-shard-00-01.l3iji5w.mongodb.net:27017,ac-llcnnor-shard-00-00.l3iji5w.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

    private final MongoClient client;
    private final MongoCollection<Document> collection;

    /*
     * Creates the MongoDB client and initializes the logs collection
     * that will be used throughout the application.
     */
    public MongoDBManager() {
        // connect to MongoDB Atlas using the configured URI
        client = MongoClients.create(URI);

        // access the project4 database
        MongoDatabase database = client.getDatabase("project4");

        // access the logs collection where mobile interactions are stored
        collection = database.getCollection("logs");
    }

    /*
     * Logs one complete interaction from the mobile application.
     * Each field captures part of the request, API interaction, or response.
     */
    public void logMobileInteraction(String searchTerm,
                                     String device,
                                     String mobileEndpoint,
                                     String thirdPartyUrl,
                                     int thirdPartyStatusCode,
                                     long thirdPartyLatencyMs,
                                     int candidateCount,
                                     String selectedCharacterName,
                                     int filmCount,
                                     boolean imageReturned,
                                     String responseStatus,
                                     String responseMessage,
                                     long requestTimestamp,
                                     long totalRequestLatencyMs) {

        // create a new document to represent one logged interaction
        Document log = new Document();

        // store information from the original mobile request
        log.append("searchTerm", safeString(searchTerm)); // character name entered by user
        log.append("device", safeString(device)); // phone or client device making request
        log.append("mobileEndpoint", safeString(mobileEndpoint)); // servlet endpoint called by mobile app
        log.append("requestTimestamp", requestTimestamp); // time when request was first received

        // store information about the third-party API request and reply
        log.append("thirdPartyUrl", safeString(thirdPartyUrl)); // Disney API URL requested by server
        log.append("thirdPartyStatusCode", thirdPartyStatusCode); // HTTP status returned by Disney API
        log.append("thirdPartyLatencyMs", thirdPartyLatencyMs); // time taken for Disney API call
        log.append("candidateCount", candidateCount); // number of candidate matches returned by API

        // store information about the server response sent back to mobile app
        log.append("selectedCharacterName", safeString(selectedCharacterName)); // final chosen character returned
        log.append("filmCount", filmCount); // number of films included in response
        log.append("imageReturned", imageReturned); // whether an image URL was returned
        log.append("responseStatus", safeString(responseStatus)); // overall result of request handling
        log.append("responseMessage", safeString(responseMessage)); // descriptive message about result
        log.append("totalRequestLatencyMs", totalRequestLatencyMs); // total end-to-end request time

        // insert the completed log document into MongoDB
        collection.insertOne(log);
    }

    /*
     * Returns all stored logs sorted from most recent to oldest
     * so they can be displayed on the dashboard.
     */
    public ArrayList<Document> getLogs() {
        // create list that will hold all retrieved log documents
        ArrayList<Document> logs = new ArrayList<>();

        // retrieve all logs and sort them by timestamp in descending order
        FindIterable<Document> results =
                collection.find().sort(new Document("requestTimestamp", -1));

        // add each retrieved document to the logs list
        for (Document doc : results) {
            logs.add(doc);
        }

        // return full list of logs
        return logs;
    }

    /*
     * Returns the total number of logged mobile requests.
     */
    public long getTotalRequests() {
        // count every document stored in the logs collection
        return collection.countDocuments();
    }

    /*
     * Returns the number of successful mobile requests.
     */
    public long getSuccessfulRequests() {
        // count only documents whose response status is SUCCESS
        return collection.countDocuments(new Document("responseStatus", "SUCCESS"));
    }

    /*
     * Computes the average latency of third-party API calls.
     */
    public double getAverageThirdPartyLatency() {
        // create list to store aggregation result
        ArrayList<Document> results = new ArrayList<>();

        // group all logs together and compute average third-party latency
        collection.aggregate(Arrays.asList(
                new Document("$group",
                        new Document("_id", null)
                                .append("avgLatency",
                                        new Document("$avg", "$thirdPartyLatencyMs")))
        )).into(results);

        // return 0 if no results were found
        if (results.isEmpty() || results.get(0).get("avgLatency") == null) {
            return 0.0;
        }

        // extract and return computed average latency
        return ((Number) results.get(0).get("avgLatency")).doubleValue();
    }

    /*
     * Computes the average total end-to-end latency of requests.
     */
    public double getAverageTotalRequestLatency() {
        // create list to store aggregation result
        ArrayList<Document> results = new ArrayList<>();

        // group all logs together and compute average total request latency
        collection.aggregate(Arrays.asList(
                new Document("$group",
                        new Document("_id", null)
                                .append("avgLatency",
                                        new Document("$avg", "$totalRequestLatencyMs")))
        )).into(results);

        // return 0 if no results were found
        if (results.isEmpty() || results.get(0).get("avgLatency") == null) {
            return 0.0;
        }

        // extract and return computed average latency
        return ((Number) results.get(0).get("avgLatency")).doubleValue();
    }

    /*
     * Returns the most frequently searched character names up to the given limit.
     */
    public ArrayList<Document> getTopSearchTerms(int limit) {
        // create list to store aggregation results
        ArrayList<Document> results = new ArrayList<>();

        // filter valid search terms, group by term, count occurrences, and sort descending
        collection.aggregate(Arrays.asList(
                new Document("$match",
                        new Document("searchTerm",
                                new Document("$nin", Arrays.asList(null, "")))),
                new Document("$group",
                        new Document("_id", "$searchTerm")
                                .append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", limit)
        )).into(results);

        // return ranked search term results
        return results;
    }

    /*
     * Returns the most common requesting devices up to the given limit.
     */
    public ArrayList<Document> getTopDevices(int limit) {
        // create list to store aggregation results
        ArrayList<Document> results = new ArrayList<>();

        // filter valid device strings, group by device, count occurrences, and sort descending
        collection.aggregate(Arrays.asList(
                new Document("$match",
                        new Document("device",
                                new Document("$nin", Arrays.asList(null, "")))),
                new Document("$group",
                        new Document("_id", "$device")
                                .append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", limit)
        )).into(results);

        // return ranked device results
        return results;
    }

    /*
     * Returns a safe non-null string so null values are not inserted into logs.
     */
    private String safeString(String value) {
        // convert null strings into empty strings before storing
        if (value == null) {
            return "";
        }

        // return original value if it is already non-null
        return value;
    }
}