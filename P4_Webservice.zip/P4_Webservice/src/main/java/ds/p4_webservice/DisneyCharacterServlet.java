// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3.

package ds.p4_webservice;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.PrintWriter;

/*
 * The DisneyCharacterServlet serves as the controller for Android requests.
 * It validates input, communicates with the model to retrieve character data,
 * handles all error conditions, and logs each interaction for analytics.
 */
@WebServlet(name = "DisneyCharacterServlet", urlPatterns = {"/getCharacter"})
public class DisneyCharacterServlet extends HttpServlet {

    private DisneyCharacterModel model;
    private MongoDBManager db;

    /*
     * Initializes the model and database manager used throughout requests.
     */
    @Override
    public void init() {
        model = new DisneyCharacterModel();
        db = new MongoDBManager();
    }

    /*
     * Handles GET requests from the Android application.
     * This method orchestrates validation, API calls, response construction,
     * error handling, and logging.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        // record the start time to compute total request latency later
        long requestStartTime = System.currentTimeMillis();

        // extract input from the mobile request
        String searchTerm = request.getParameter("name");
        String device = request.getHeader("User-Agent");
        String mobileEndpoint = request.getRequestURI();

        // ensure device string is always defined for logging consistency
        if (device == null || device.trim().isEmpty()) {
            device = "Unknown device";
        }

        // configure response format to JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JSONObject jsonResponse = new JSONObject();

        // initialize variables that will be used for logging this request
        String responseStatus = "UNKNOWN";
        String responseMessage = "";
        String thirdPartyUrl = "";
        int thirdPartyStatusCode = -1;
        long thirdPartyLatencyMs = 0;
        int candidateCount = 0;
        String selectedCharacterName = "";
        int filmCount = 0;
        boolean imageReturned = false;
        long totalRequestLatencyMs;

        try {

            // validate input to ensure search term is present
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

                responseStatus = "INVALID_INPUT";
                responseMessage = "Invalid input: character name cannot be empty.";

                jsonResponse.put("error",
                        "Invalid input: character name cannot be empty.");

            } else {

                // clean up whitespace for consistent processing
                searchTerm = searchTerm.trim();

                // call the model to retrieve data from the Disney API
                DisneyCharacterModel.ApiSearchResult apiResult =
                        model.getCharactersByName(searchTerm);

                // extract API metadata for logging
                thirdPartyUrl = apiResult.getRequestUrl();
                thirdPartyStatusCode = apiResult.getStatusCode();
                thirdPartyLatencyMs = apiResult.getLatencyMs();

                // handle cases where the API call failed
                if (!apiResult.isSuccess()) {

                    String apiError = apiResult.getErrorMessage();
                    response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);

                    // distinguish between invalid data and API unavailability
                    if (apiError != null && apiError.toLowerCase().contains("invalid data")) {

                        responseStatus = "THIRD_PARTY_INVALID_DATA";
                        responseMessage = apiError;

                        jsonResponse.put("error",
                                "Received unexpected data from Disney API. Please try again.");

                    } else {

                        responseStatus = "THIRD_PARTY_API_UNAVAILABLE";
                        responseMessage = apiError;

                        jsonResponse.put("error",
                                "External Disney API is currently unavailable. Please try again later.");
                    }

                } else {

                    // retrieve all candidate matches returned by the API
                    JSONArray candidates = apiResult.getCandidates();
                    candidateCount = candidates.length();

                    // handle case where no results were returned
                    if (candidateCount == 0) {
                        response.setStatus(HttpServletResponse.SC_NOT_FOUND);

                        responseStatus = "NO_RESULTS";
                        responseMessage = "No characters matched the search term.";

                        jsonResponse.put("error",
                                "Hmm, this Disney character doesn't seem to exist; please check your spelling or try again!");

                    } else {

                        // apply ranking logic to select the best match
                        JSONObject bestMatch = selectBestMatch(candidates, searchTerm);

                        // handle rare case where no suitable match is found
                        if (bestMatch == null) {
                            response.setStatus(HttpServletResponse.SC_NOT_FOUND);

                            responseStatus = "NO_SUITABLE_MATCH";
                            responseMessage = "Candidates returned but no suitable match.";

                            jsonResponse.put("error", "No suitable match found.");

                        } else {

                            // extract only the fields needed for the response
                            selectedCharacterName = bestMatch.optString("name", "");
                            String imageUrl = bestMatch.optString("imageUrl", "");
                            JSONArray films = bestMatch.optJSONArray("films");

                            // ensure films array is always valid
                            if (films == null) {
                                films = new JSONArray();
                            }

                            // compute derived values for logging
                            filmCount = films.length();
                            imageReturned = imageUrl != null && !imageUrl.trim().isEmpty();

                            // construct JSON response to send back to the client
                            jsonResponse.put("name", selectedCharacterName);
                            jsonResponse.put("imageUrl", imageUrl);
                            jsonResponse.put("films", films);

                            responseStatus = "SUCCESS";
                            responseMessage = "Character found successfully.";
                        }
                    }
                }
            }

        } catch (Exception e) {

            // handle unexpected server-side errors to prevent crashes
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            responseStatus = "SERVER_ERROR";
            responseMessage = "Unexpected server-side error.";

            jsonResponse = new JSONObject();
            jsonResponse.put("error",
                    "A server error occurred. Please try again.");
        } finally {

            // compute total request latency
            totalRequestLatencyMs = System.currentTimeMillis() - requestStartTime;

            // log the interaction for dashboard analytics
            db.logMobileInteraction(
                    searchTerm,
                    device,
                    mobileEndpoint,
                    thirdPartyUrl,
                    thirdPartyStatusCode,
                    thirdPartyLatencyMs,
                    candidateCount,
                    selectedCharacterName,
                    filmCount,
                    imageReturned,
                    responseStatus,
                    responseMessage,
                    requestStartTime,
                    totalRequestLatencyMs
            );

            // send JSON response back to the client
            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        }
    }

    /*
     * Selects the best matching character based on normalized comparison rules.
     */
    private JSONObject selectBestMatch(JSONArray candidates, String input) {

        // normalize user input to enable consistent comparison (lowercase, no punctuation)
        String normalizedInput = normalize(input);

        // placeholders for fallback matches if exact match is not found
        JSONObject startsWithMatch = null;
        JSONObject containsMatch = null;

        // iterate through all candidate characters returned by the API
        for (int i = 0; i < candidates.length(); i++) {

            // retrieve current candidate character object
            JSONObject character = candidates.getJSONObject(i);

            // normalize candidate name to match comparison format
            String normalizedName = normalize(character.optString("name", ""));

            // check for highest priority: exact match between input and candidate name
            if (normalizedName.equals(normalizedInput)) return character;

            // check for second priority: candidate name starts with input (store first occurrence)
            if (startsWithMatch == null && normalizedName.startsWith(normalizedInput)) {
                startsWithMatch = character;
            }

            // check for third priority: candidate name contains input anywhere (store first occurrence)
            if (containsMatch == null && normalizedName.contains(normalizedInput)) {
                containsMatch = character;
            }
        }

        // return best available fallback match if no exact match was found
        if (startsWithMatch != null) return startsWithMatch;

        // final fallback: return contains match (may be null if nothing matched)
        return containsMatch;
    }

    /*
     * Normalizes strings by removing punctuation and converting to lowercase.
     */
    private String normalize(String s) {
        return s.toLowerCase().replaceAll("[^a-z ]", "").trim();
    }
}