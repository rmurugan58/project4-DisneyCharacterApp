// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3.

package ds.p4_webservice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/*
 * The DisneyCharacterModel is responsible for communicating with the
 * external Disney API. It performs a search based on a character name
 * and returns both the results and metadata used for logging.
 */
public class DisneyCharacterModel {

    /*
     * ApiSearchResult encapsulates the outcome of a third-party API request.
     */
    public static class ApiSearchResult {
        private final boolean success;
        private final int statusCode;
        private final long latencyMs;
        private final String requestUrl;
        private final JSONArray candidates;
        private final String errorMessage;

        public ApiSearchResult(boolean success,
                               int statusCode,
                               long latencyMs,
                               String requestUrl,
                               JSONArray candidates,
                               String errorMessage) {
            this.success = success;
            this.statusCode = statusCode;
            this.latencyMs = latencyMs;
            this.requestUrl = requestUrl;
            this.candidates = candidates;
            this.errorMessage = errorMessage;
        }

        public boolean isSuccess() { return success; }
        public int getStatusCode() { return statusCode; }
        public long getLatencyMs() { return latencyMs; }
        public String getRequestUrl() { return requestUrl; }
        public JSONArray getCandidates() { return candidates; }
        public String getErrorMessage() { return errorMessage; }
    }

    /*
     * Sends a request to the Disney API using the provided name.
     */
    public ApiSearchResult getCharactersByName(String name) {

        HttpURLConnection conn = null;
        BufferedReader reader = null;

        try {
            // build request URL using encoded name
            String encodedName = name.replace(" ", "%20");
            String requestUrl =
                    "https://api.disneyapi.dev/character?name=" + encodedName;

            long startTime = System.currentTimeMillis();

            // open connection to third-party API
            URL url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int statusCode = conn.getResponseCode();

            // choose correct input stream based on response status
            if (statusCode >= 200 && statusCode < 300) {
                reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)
                );
            } else {
                reader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8)
                );
            }

            // read full response into string builder
            StringBuilder responseBuilder = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                responseBuilder.append(line);
            }

            long latencyMs = System.currentTimeMillis() - startTime;

            // handle non-successful API response
            if (statusCode < 200 || statusCode >= 300) {
                return new ApiSearchResult(
                        false, statusCode, latencyMs, requestUrl,
                        new JSONArray(),
                        "Third-party API returned status " + statusCode
                );
            }

            // parse JSON response
            JSONObject json = new JSONObject(responseBuilder.toString());
            JSONArray data = json.optJSONArray("data");

            // handle malformed API response
            if (data == null) {
                return new ApiSearchResult(
                        false, statusCode, latencyMs, requestUrl,
                        new JSONArray(),
                        "Third-party API returned invalid data."
                );
            }

            // return successful result
            return new ApiSearchResult(true, statusCode, latencyMs, requestUrl, data, null);

        } catch (Exception e) {
            // handle failure to connect to API
            return new ApiSearchResult(
                    false, 500, 0, "",
                    new JSONArray(),
                    "Unable to contact third-party API."
            );
        } finally {
            // close resources
            try {
                if (reader != null) reader.close();
            } catch (Exception ignored) {}

            if (conn != null) conn.disconnect();
        }
    }
}