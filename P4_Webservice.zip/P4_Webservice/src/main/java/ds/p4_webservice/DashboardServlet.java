// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3.

package ds.p4_webservice;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;

/*
 * The DashboardServlet handles requests for the operations dashboard.
 * It retrieves log data and computed analytics from MongoDB and forwards
 * them to the JSP for display.
 *
 * This servlet only reads data and does not log any interactions,
 * ensuring that only mobile application requests are recorded.
 */
@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private MongoDBManager db;

    /*
     * Initializes the MongoDBManager used to access stored logs and analytics.
     */
    @Override
    public void init() {
        db = new MongoDBManager();
    }

    /*
     * Handles GET requests to the dashboard endpoint.
     * Retrieves logs and analytics data and forwards them to dashboard.jsp.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // retrieve raw logs from database
        ArrayList<Document> logs = db.getLogs();

        // retrieve analytics data from database
        ArrayList<Document> topSearchTerms = db.getTopSearchTerms(5);
        ArrayList<Document> topDevices = db.getTopDevices(5);

        long totalRequests = db.getTotalRequests();
        long successfulRequests = db.getSuccessfulRequests();
        double avgThirdPartyLatency = db.getAverageThirdPartyLatency();
        double avgTotalRequestLatency = db.getAverageTotalRequestLatency();

        // attach all retrieved data to request for JSP rendering
        request.setAttribute("logs", logs);
        request.setAttribute("topSearchTerms", topSearchTerms);
        request.setAttribute("topDevices", topDevices);
        request.setAttribute("totalRequests", totalRequests);
        request.setAttribute("successfulRequests", successfulRequests);
        request.setAttribute("avgThirdPartyLatency", avgThirdPartyLatency);
        request.setAttribute("avgTotalRequestLatency", avgTotalRequestLatency);

        // forward request to dashboard view
        RequestDispatcher view = request.getRequestDispatcher("/dashboard.jsp");
        view.forward(request, response);
    }
}