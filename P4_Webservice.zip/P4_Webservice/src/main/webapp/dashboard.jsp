<%-- Author: Rathi Murugan (rmurugan) --%>
<%-- The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3. --%>

<%@ page import="java.util.ArrayList" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %>
<%@ page import="org.bson.Document" %>

<%
    // retrieve logs and analytics data passed from DashboardServlet
    ArrayList<Document> logs = (ArrayList<Document>) request.getAttribute("logs");
    ArrayList<Document> topSearchTerms =
            (ArrayList<Document>) request.getAttribute("topSearchTerms");
    ArrayList<Document> topDevices =
            (ArrayList<Document>) request.getAttribute("topDevices");

    // retrieve summary analytics values
    long totalRequests = (Long) request.getAttribute("totalRequests");
    long successfulRequests = (Long) request.getAttribute("successfulRequests");
    double avgThirdPartyLatency = (Double) request.getAttribute("avgThirdPartyLatency");
    double avgTotalRequestLatency = (Double) request.getAttribute("avgTotalRequestLatency");

    // compute success rate from total and successful requests
    double successRate = 0.0;
    if (totalRequests > 0) {
        successRate = ((double) successfulRequests / totalRequests) * 100.0;
    }

    // formatter used to convert timestamp into readable date string
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Disney Character Dashboard</title>

    <style>
        /* basic page styling for readability */
        body {
            font-family: Arial, sans-serif;
            margin: 24px;
            background-color: #f7f9fc;
            color: #1f2937;
        }

        h1, h2 {
            margin-bottom: 10px;
        }

        /* container for summary analytics cards */
        .summary-boxes {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        /* styling for individual analytics cards */
        .summary-card {
            background: white;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            padding: 16px;
            min-width: 220px;
        }

        .summary-card h3 {
            margin: 0 0 8px 0;
            font-size: 16px;
        }

        .summary-card p {
            margin: 0;
            font-size: 22px;
            font-weight: bold;
        }

        /* table styling for logs and analytics */
        table {
            border-collapse: collapse;
            width: 100%;
            background: white;
            margin-bottom: 28px;
        }

        th, td {
            border: 1px solid #d1d5db;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #e5e7eb;
        }

        .section {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>

<!-- dashboard title and description -->
<h1>Disney Character Search Dashboard</h1>
<p>This dashboard shows usage analytics and full logs for the "Disney Characters in Film" mobile-phone interactions with the web service.</p>

<%-- summary analytics section --%>
<div class="summary-boxes">

    <!-- display total number of requests -->
    <div class="summary-card">
        <h3>Total Mobile Requests</h3>
        <p><%= totalRequests %></p>
    </div>

    <!-- display number of successful requests -->
    <div class="summary-card">
        <h3>Successful Requests</h3>
        <p><%= successfulRequests %></p>
    </div>

    <!-- display computed success rate -->
    <div class="summary-card">
        <h3>Success Rate</h3>
        <p><%= String.format("%.2f%%", successRate) %></p>
    </div>

    <!-- display average third-party API latency -->
    <div class="summary-card">
        <h3>Avg Third-Party Latency</h3>
        <p><%= String.format("%.2f ms", avgThirdPartyLatency) %></p>
    </div>

    <!-- display average total request latency -->
    <div class="summary-card">
        <h3>Avg End-to-End Latency</h3>
        <p><%= String.format("%.2f ms", avgTotalRequestLatency) %></p>
    </div>

</div>

<%-- top search terms section --%>
<div class="section">
    <h2>Top Search Terms</h2>

    <table>
        <tr>
            <th>Search Term</th>
            <th>Count</th>
        </tr>

        <%
            // iterate through aggregated search term results
            for (Document d : topSearchTerms) {
        %>
        <tr>
            <td><%= d.getString("_id") %></td>
            <td><%= d.get("count") %></td>
        </tr>
        <%
            }
        %>
    </table>
</div>

<%-- top devices used section --%>
<div class="section">
    <h2>Top Devices</h2>

    <table>
        <tr>
            <th>Device</th>
            <th>Count</th>
        </tr>

        <%
            // iterate through aggregated device usage results
            for (Document d : topDevices) {
        %>
        <tr>
            <td><%= d.getString("_id") %></td>
            <td><%= d.get("count") %></td>
        </tr>
        <%
            }
        %>
    </table>
</div>

<%-- full logs section --%>
<div class="section">
    <h2>Full Mobile Request Logs</h2>

    <table>
        <tr>
            <th>Timestamp</th>
            <th>Search Term</th>
            <th>Device</th>
            <th>Mobile Endpoint</th>
            <th>Third-Party URL</th>
            <th>Third-Party Status</th>
            <th>Third-Party Latency (ms)</th>
            <th>Candidate Count</th>
            <th>Selected Character</th>
            <th>Film Count</th>
            <th>Image Returned</th>
            <th>Response Status</th>
            <th>Response Message</th>
            <th>Total Request Latency (ms)</th>
        </tr>

        <%
            // iterate through all logs retrieved from MongoDB
            for (Document d : logs) {

                // convert timestamp into human-readable format
                Long timestamp = d.getLong("requestTimestamp");
                String formattedTime = "";

                if (timestamp != null) {
                    formattedTime = sdf.format(new Date(timestamp));
                }
        %>
        <tr>
            <td><%= formattedTime %></td>
            <td><%= d.getString("searchTerm") %></td>
            <td><%= d.getString("device") %></td>
            <td><%= d.getString("mobileEndpoint") %></td>
            <td><%= d.getString("thirdPartyUrl") %></td>
            <td><%= d.get("thirdPartyStatusCode") %></td>
            <td><%= d.get("thirdPartyLatencyMs") %></td>
            <td><%= d.get("candidateCount") %></td>
            <td><%= d.getString("selectedCharacterName") %></td>
            <td><%= d.get("filmCount") %></td>
            <td><%= d.get("imageReturned") %></td>
            <td><%= d.getString("responseStatus") %></td>
            <td><%= d.getString("responseMessage") %></td>
            <td><%= d.get("totalRequestLatencyMs") %></td>
        </tr>
        <%
            }
        %>
    </table>
</div>

</body>
</html>