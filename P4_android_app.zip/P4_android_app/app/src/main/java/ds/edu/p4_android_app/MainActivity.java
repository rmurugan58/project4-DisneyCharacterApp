// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3 and references Android lab 8.

package ds.edu.p4_android_app;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/*
 * This class is the main Android activity for the application.
 * It handles user input and updates the UI based on results
 * returned from the GetCharacter helper class.
 */
public class MainActivity extends AppCompatActivity {

    MainActivity me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // set layout for the activity
        setContentView(R.layout.activity_main);

        final MainActivity ma = this;

        // retrieve reference to submit button from layout
        Button submitButton = (Button) findViewById(R.id.submit);

        // attach click listener to handle user interaction
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View viewParam) {

                // read user input from text field
                String searchTerm =
                        ((EditText) findViewById(R.id.searchTerm)).getText().toString();

                Log.d("Trace", "onClick");
                Log.d("Trace", "searchTerm = " + searchTerm);

                // delegate network request to helper class
                GetCharacter gc = new GetCharacter();
                gc.search(searchTerm, ma);
            }
        });
    }

    /*
     * Callback method used by GetCharacter when response is ready.
     * Updates UI with character info and image.
     */
    public void characterReady(String resultText, Bitmap picture) {

        Log.d("Trace", "characterReady");

        // retrieve UI elements for updating display
        TextView resultView = (TextView) findViewById(R.id.resultText);
        EditText searchView = (EditText) findViewById(R.id.searchTerm);
        ImageView pictureView = (ImageView) findViewById(R.id.imageView);

        // update text view with result or error message
        resultView.setText(resultText);

        // update image view depending on whether image is available
        if (picture != null) {
            pictureView.setImageBitmap(picture);
            pictureView.setVisibility(View.VISIBLE);
            Log.d("Trace", "picture was found");
        } else {
            pictureView.setImageResource(R.mipmap.ic_launcher);
            pictureView.setVisibility(View.INVISIBLE);
            Log.d("Trace", "No picture available");
        }

        // reset input field for next search
        searchView.setText("");

        // refresh image view display
        pictureView.invalidate();
    }
}