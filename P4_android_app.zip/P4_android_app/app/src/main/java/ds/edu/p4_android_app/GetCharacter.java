// Author: Rathi Murugan (rmurugan)
// The rest of this file, including code and comments, was written with the aid of and generated/modified by the Chatgpt LLM model 5.3 and references Android lab 8.

package ds.edu.p4_android_app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/*
 * Handles HTTP request to servlet, parses JSON response,
 * and returns results to MainActivity.
 */
public class GetCharacter {

    public void search(String name, MainActivity activity) {

        // run network operation on a background thread to avoid blocking UI
        new Thread(() -> {

            try {
                // encode spaces in user input for safe URL usage
                String encoded = name.replace(" ", "%20");

                // build URL to call servlet endpoint
                URL url = new URL(
                        "https://musical-memory-wr55rxrrgxvpf9gxw-8080.app.github.dev/getCharacter?name=" + encoded
                );

                // open HTTP connection to servlet
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                // read response stream from servlet
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream())
                );

                StringBuilder response = new StringBuilder();
                String line;

                // read full response into string builder
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                // close reader after reading response
                reader.close();

                // parse response string into JSON object
                JSONObject json = new JSONObject(response.toString());

                // check if servlet returned an error message
                if (json.has("error")) {
                    try {
                        String errorMsg = json.getString("error");

                        // update UI with error message on main thread
                        activity.runOnUiThread(() ->
                                activity.characterReady(errorMsg, null)
                        );

                    } catch (Exception e) {
                        e.printStackTrace();

                        // fallback error handling if parsing fails
                        activity.runOnUiThread(() ->
                                activity.characterReady("Unknown error", null)
                        );
                    }
                    return;
                }

                // extract character name and image URL from JSON response
                String nameResult = json.getString("name");
                String imageUrl = json.getString("imageUrl");

                // extract films array from JSON response
                JSONArray films = json.getJSONArray("films");

                // build formatted display string for UI
                StringBuilder display = new StringBuilder();
                display.append("Name: ").append(nameResult).append("\n\n");

                // handle case where no films are available
                if (films.length() == 0) {
                    display.append("Aww, looks like ")
                            .append(nameResult)
                            .append(" is not in any Disney films!");
                } else {
                    display.append("Films:\n");

                    // iterate through films and append each one to display
                    for (int i = 0; i < films.length(); i++) {
                        display.append("- ").append(films.getString(i)).append("\n");
                    }
                }

                // download image from provided URL and convert to bitmap
                URL imgUrl = new URL(imageUrl);
                Bitmap bitmap = BitmapFactory.decodeStream(
                        imgUrl.openConnection().getInputStream()
                );

                // update UI with character data and image on main thread
                activity.runOnUiThread(() ->
                        activity.characterReady(display.toString(), bitmap)
                );

            } catch (Exception e) {
                e.printStackTrace();

                // handle network or parsing failure gracefully
                activity.runOnUiThread(() ->
                        activity.characterReady("Error retrieving data", null)
                );
            }

        }).start();
    }
}